# 🚀 MULTI-LAYER7 🚀

# Tree
* [Read this Pls](#plz-%EF%B8%8F)
* [Credits](#Credits)
* [T.O.S](#TOS)

# Plz ♥️
It would help me a lot if you give a star ⭐ to this repository.<br>
One star from you = more desire to continue updating Stanley

# Credits
```sh
aqu1337
kxndemir
all terminaljunkies users.
```

# TOS:
```sh
Do not attack government pages (.gov/.gob), educational pages (.edu) or the United States Department of Defense (.mil), 
the creator is not responsible for the damage caused by the attacks. 
remember: you are responsible for the attacks since this tool was created for educational purposes
```
